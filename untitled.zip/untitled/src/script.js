const game = document.getElementById("game");
const scoreDisplay = document.getElementById("score");
let score = 0;

function spawnBox() {
  // إنشاء مربع
  const box = document.createElement("div");
  box.classList.add("box");

  // مكان عشوائي
  const x = Math.random() * (game.clientWidth - 50);
  const y = Math.random() * (game.clientHeight - 50);
  box.style.left = `${x}px`;
  box.style.top = `${y}px`;

  game.appendChild(box);

  // عند الضغط
  box.addEventListener("click", () => {
    score++;
    scoreDisplay.textContent = `Score: ${score}`;
    box.remove();
  });

  // يختفي بعد ثانيتين
  setTimeout(() => {
    if (game.contains(box)) {
      box.remove();
    }
  }, 2000);
}

// يولّد مربع كل 1.5 ثانية
setInterval(spawnBox, 1500);